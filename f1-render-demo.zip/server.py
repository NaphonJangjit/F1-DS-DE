from pathlib import Path
from fastapi.staticfiles import StaticFiles
from _web_api import create_app

app = create_app()
app.mount("/", StaticFiles(directory=Path(__file__).parent / "public", html=True), name="web")
